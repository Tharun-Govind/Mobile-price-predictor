This folder contains the code for cleaning data set and forming a new data set which is cleaned.
