This folder contains code used for gathering the data set and creating csv file
